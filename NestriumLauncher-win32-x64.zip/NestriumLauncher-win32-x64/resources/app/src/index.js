const remoteMain = require('@electron/remote/main')
remoteMain.initialize()

// Requirements
const { app, BrowserWindow, ipcMain } = require('electron')
const elejs                    = require('ejs-electron')
const path                          = require('path')
const { pathToFileURL }             = require('url')



// Redirect distribution index event from preloader to renderer.
ipcMain.on('distributionIndexDone', (event, res) => {
    event.sender.send('distributionIndexDone', res)
})

// Disable hardware acceleration.
// https://electronjs.org/docs/tutorial/offscreen-rendering
app.disableHardwareAcceleration()

// Keep a global reference of the window object, if you don't, the window will
// be closed automatically when the JavaScript object is garbage collected.
let win

function createWindow() {

    win = new BrowserWindow({
        width: 980,
        height: 616,
        icon: getPlatformIcon('Icon'),
        frame: false,
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false
        },
        backgroundColor: '#131313',
    })
    remoteMain.enable(win.webContents)

    win.loadURL(pathToFileURL(path.join(__dirname, 'assets', 'app.ejs')).toString())

    win.removeMenu()

    win.resizable = false

    win.on('closed', () => {
        win = null
    })
}

function getPlatformIcon(filename){
    let ext
    switch(process.platform) {
        case 'win32':
            ext = 'ico'
            break
        case 'darwin':
        case 'linux':
        default:
            ext = 'png'
            break
    }

    return path.join(__dirname, 'assets', 'images', `${filename}.${ext}`)
}

app.on('ready', createWindow)

app.on('window-all-closed', () => {
    // On macOS it is common for applications and their menu bar
    // to stay active until the user quits explicitly with Cmd + Q
    if (process.platform !== 'darwin') {
        app.quit()
    }
})

app.on('activate', () => {
    // On macOS it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (win === null) {
        createWindow()
    }
})

// DISCORD RPC //

const DiscordRPC = require('discord-rpc'); // Requiring the discord-rpc package.
const client = new DiscordRPC.Client({ transport: 'ipc' }); // Creating a client variable with is our rpc client.
const clientId = "937302931877802014";

(async () => {
    client.on('ready', async () => { // Calling the ready event.
        if (Math.random().toFixed(0) == 0) {
            await client.setActivity({ // Setting the Rich Presence Activity based on what is passed in here.
                buttons: [{ label: "Play", url: "https://nestrium.github.io" }],
                details: "Modded Minecraft Server",
                largeImageKey: "nestrium_ingot",
                largeImageText: "Playing Nestrium!",
                startTimestamp: new Date()
            }).catch(err => console.log(err));
        } else {
            await client.setActivity({ // Setting the Rich Presence Activity based on what is passed in here.
                buttons: [{ label: "Play", url: "https://nestrium.github.io" }],
                details: "Modded Minecraft Server",
                largeImageKey: "ultrosium_ingot",
                largeImageText: "Playing Nestrium!",
                startTimestamp: new Date()
            }).catch(err => console.log(err));
        }

        console.log("Discord Rich Presence has been enabled.");
    });

    await client.login({clientId}).catch(console.error); // Logging into our application.
})();