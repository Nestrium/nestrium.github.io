const { Client, Authenticator } = require('minecraft-launcher-core');
const launcher = new Client();
const msmc = require("msmc");
const fetch = require("node-fetch");
const { app } = require("electron")

let minRam = document.getElementById("minRam").value;
let maxRam = document.getElementById("maxRam").value;

let appData = process.env.APPDATA

document.getElementById("msa-launch").addEventListener('click', () => {
    document.getElementById("msa-launch").disabled = true;
    msmc.setFetch(fetch)
    msmc.fastLaunch("raw",
        (update) => {
            //A hook for catching loading bar events and errors, standard with MSMC
            console.log("Login Status Update")
            console.log(update)
            document.getElementById("msa-launch").innerHTML = update.data;
        }).then(result => {
            //Let's check if we logged in?
            if (msmc.errorCheck(result)){
                console.log(result.reason)
                alert(result.reason)
                return;
            }
            //If the login works
            let opts = {
                clientPackage: "https://nestrium.github.io/client.zip",
                // Pulled from the Minecraft Launcher core docs , this function is the star of the show
                authorization: msmc.getMCLC().getAuth(result),
                root: appData + "\\.nestrium",
                forge: appData + "\\.nestrium\\forge.jar",
                version: {
                    number: "1.16.5",
                    type: "release"
                },
                memory: {
                    max: maxRam + "G",
                    min: minRam + "G"
                }
            }
            document.getElementById("msa-launch").innerHTML = "Loading...";
            console.log("Starting!")
            launcher.launch(opts);

            launcher.on('debug', (e) => console.log(e));
            launcher.on('data', (e) => console.log(e));
            launcher.on('progress', (e) => console.log(e))
        }).catch(reason => {
            //If the login fails
            console.log("We failed to log someone in because : " + reason);
            alert("Could not login: " + reason)
            document.getElementById("msa-launch").disabled = false;
            document.getElementById("msa-launch").innerHTML = "Launch";
        })
})

let usernametextbox = document.getElementById("email").value;
let passtextbox = document.getElementById("password").value;
document.getElementById("mojang-launch").addEventListener('click', () => {
    Authenticator.getAuth(usernametextbox, passtextbox).then(() => {
        document.getElementById("mojang-launch").disabled = true;
        let opts = {
            clientPackage: null,
            // For production launchers, I recommend not passing 
            // the getAuth function through the authorization field and instead
            // handling authentication outside before you initialize
            // MCLC so you can handle auth based errors and validation!
            authorization: Authenticator.getAuth(usernametextbox, passtextbox),
            root: "./minecraft",
            version: {
                number: "1.16.5",
                type: "release"
            },
            memory: {
                max: maxRam + "G",
                min: minRam + "G"
            }
        }
    
        launcher.launch(opts);
        
        launcher.on('debug', (e) => console.log(e));
        launcher.on('data', (e) => console.log(e));
    }).catch(reason => {
        console.log("Error: " + error)
        alert(error)
    })
})

launcher.on("close", () => {
    document.getElementById("msa-launch").disabled = false;
    document.getElementById("msa-launch").innerHTML = "Launch";
})

launcher.on("progress", (e) => {
    console.log(e)
    document.getElementById("msa-launch").innerHTML = "Downloading : " + e.type;
})
