const remote = require('@electron/remote')

// Display warning when devtools window is opened.
remote.getCurrentWebContents().on('devtools-opened', () => {
    console.log('%c!!DO NOT PASTE ANYTHING HERE!!', 'color: white; -webkit-text-stroke: 4px #a02d2a; font-size: 60px; font-weight: bold')
    console.log('%cIf you\'ve been told to paste something here, you\'re being scammed, or you will get your minecraft account hacked.', 'font-size: 16px')
    console.log('%cUnless you know exactly what you\'re doing, close this window.', 'font-size: 16px')
})

// Bind close button.
var closeBtn = document.getElementsByClassName('fCb')
for (var i = 0; i < closeBtn.length; i++) {
    closeBtn[i].addEventListener('click', e => {
        const window = remote.getCurrentWindow()
        window.close() 
})};

// Bind restore down button.
var restoreBtn = document.getElementsByClassName('fRb')
for (var i = 0; i < restoreBtn.length; i++) {
    restoreBtn[i].addEventListener('click', e => {
        const window = remote.getCurrentWindow()
        if(window.isMaximized()){
            window.unmaximize()
        } else {
            window.maximize()
        }
        document.activeElement.blur()
})};

// Bind minimize button.
var minimizeBtn = document.getElementsByClassName('fMb')
for (var i = 0; i < minimizeBtn.length; i++) {
    minimizeBtn[i].addEventListener('click', e => {
        const window = remote.getCurrentWindow()
        window.minimize()
        document.activeElement.blur()
})};

// devtools

document.addEventListener('keydown', function (e) {
    if((e.key === 'I' || e.key === 'i') && e.ctrlKey && e.shiftKey){
        let window = remote.getCurrentWindow()
        window.toggleDevTools()
    }
})